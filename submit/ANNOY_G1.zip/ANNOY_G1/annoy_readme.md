pip install annoy
pip install numpy

python vector_search_annoy.py