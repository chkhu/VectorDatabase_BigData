需要安装：  pip install nmslib

若查询需要的返回最近邻数量需要修改，修改k=50


